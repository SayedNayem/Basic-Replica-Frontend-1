# replica-frontend

A Pen created on CodePen.io. Original URL: [https://codepen.io/sayednayem6992/pen/xxjaGQY](https://codepen.io/sayednayem6992/pen/xxjaGQY).

